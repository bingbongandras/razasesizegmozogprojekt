console.clear()

const swappable = new Swappable.default(document.querySelectorAll('.grid__container'), {
  draggable: '.grid__element'
});

